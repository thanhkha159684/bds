﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'devtools', 'ku',
{
	devTools :
	{
		title		: 'زانیاری توخم',
		dialogName	: 'ناوی په‌نجه‌ره‌ی دیالۆگ',
		tabName		: 'ناوی بازده‌ر تاب',
		elementId	: 'ناسنامه‌ی توخم',
		elementType	: 'جۆری توخم'
	}
});
